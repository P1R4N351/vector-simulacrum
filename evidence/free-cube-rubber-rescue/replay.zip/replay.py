import rubber as r
import mujoco as mj
import xml.etree.ElementTree as ET
p=[168.7,23.4,.23,.92,.09,.75]
for s in (1,-1):print('normal',s,r.trial(p,s,True,2))
tree=ET.parse(r.base/'caps.xml')
contact=tree.getroot().find('contact')
if contact is None:contact=ET.SubElement(tree.getroot(),'contact')
def bodies(ids):return {r.model.body(r.model.geom_bodyid[i]).name for i in ids}
for a in bodies(r.actor):
 for b in bodies(r.patient):ET.SubElement(contact,'exclude',body1=a,body2=b)
r.model=mj.MjModel.from_xml_string(ET.tostring(tree.getroot(),encoding='unicode'))
for s in (1,-1):print('no direct',s,r.trial(p,s,False,2))
