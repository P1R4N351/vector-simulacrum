from pathlib import Path
import json,math,sys
from concurrent.futures import ProcessPoolExecutor
import mujoco as mj
import numpy as np
base=Path(__file__).resolve().parent
model=mj.MjModel.from_xml_path(str(base/'caps.xml'))
names=[model.geom(i).name for i in range(model.ngeom)]
cube={i for i,n in enumerate(names) if n.startswith("cube_")}
pf={i for i,n in enumerate(names) if n.startswith(("patient_lift_fork_geom","patient_fork_side_"))}
rf={i for i,n in enumerate(names) if n.startswith(("lift_fork_geom","fork_side_"))}
patient={i for i,n in enumerate(names) if n.startswith("patient_")}
actor=set(range(model.ngeom))-cube-patient-{names.index("floor"),names.index("table")}
lo,hi=model.actuator('lift').ctrlrange
def pose(d,p):
 b=d.body(p+'chassis')
 return [*b.xpos,*b.xquat,*[d.joint(p+j+'_joint').qpos[0] for j in ('head','lift','wheel_fl','wheel_fr','wheel_rl','wheel_rr')]]
def trial(params,side,save=False,index=0):
 yaw,offset,h0,power,delay,press=params
 d=mj.MjData(model)
 mj.mj_setState(model,d,np.load(base/f'seat{index}'/f'start{side}.npy'),mj.mjtState.mjSTATE_INTEGRATION)
 d.joint('cube_root').qpos[2]+=.00015;d.time=0
 seat=json.loads((base/'seats.json').read_text())[index]
 start,end,dx,dy,cy,roll,back,_=seat['p']
 yaw=math.radians(yaw)*side;f=np.array([math.cos(yaw),math.sin(yaw)])
 r=d.joint('root').qpos;r[:2]=np.array(seat['center'][str(side)])-.113*f+np.array([-f[1],f[0]])*side*offset*.001
 r[3:]=[math.cos(yaw/2),0,0,math.sin(yaw/2)]
 d.joint('lift_joint').qpos[0]=lo+h0*(hi-lo);d.joint('wrist_joint').qpos[0]=-d.joint('lift_joint').qpos[0]
 mj.mj_forward(model,d)
 hit=None;held=0;dual=0;direct=0;frames=[];logs=[];slip=None;startrel=None;acquired=None
 last_up=1;best=180;endclear=True
 for i in range(540):
  t=(i*10)*.001
  d.ctrl[7]=lo+(hi-lo)*start+((lo+(hi-lo)*end)-(lo+(hi-lo)*start))*np.clip((t-.30)/.55,0,1)+back*(hi-lo)*np.clip((t-.91)/.24,0,1)
  d.xfrc_applied[model.body('cube').id,1]=-.28*side if .32<t<.80 else 0
  elapsed=t-hit if hit is not None else max(-1,t-2.6) if t>2.6 else -1
  rise=np.clip((elapsed-delay)/.23,0,1);lower=np.clip((elapsed-delay-press-1.)/.45,0,1)
  d.ctrl[3]=lo+(hi-lo)*(h0+(1-h0)*rise)*(1-lower)
  d.ctrl[:2]=0 if t<1.5 else power if elapsed<delay+press else -.50 if elapsed<delay+press+.8 else 0
  pc=rc=dc=False;pm=[];rm=[]
  for j in range(10 if save else 1):
   mj.mj_step(model,d,nstep=1 if save else 10)
   pc=rc=dc=any_actor=False
   pm=[];rm=[]
   for c in d.contact:
    a,b=c.geom
    if a in cube or b in cube:
     other=b if a in cube else a
     if other in pf:pc=True;pm=[c.pos.tolist()] if save else []
     if other in rf:rc=True;rm=[c.pos.tolist()] if save else []
     any_actor|=other in actor
    if (a in actor and b in patient) or (b in actor and a in patient):dc=True
   direct+=int(dc)
   dual+=int(pc and rc)
   if i>=470:
    last_up=min(last_up,d.body('patient_chassis').xmat[8]);endclear &= not(any_actor or dc)
   if save: logs.append([d.time,int(pc),int(rc),int(dc),d.body('patient_chassis').xmat[8]])
  if hit is None and rc:hit=t
  if 1.2<=t<1.5:held+=pc
  wrist=d.body('patient_lift_fork'); block=d.body('cube')
  rel=wrist.xmat.reshape(3,3).T@(block.xpos-wrist.xpos)
  if i==149:startrel=rel.copy()
  dist=0 if startrel is None else float(np.linalg.norm(rel-startrel)*1000)
  if i>150 and dist>4 and slip is None:slip=t
  tilt=math.degrees(math.acos(np.clip(d.body('patient_chassis').xmat[8],-1,1)))
  if hit is not None:best=min(best,tilt)
  if save and i%3==0:frames.append(dict(t=t,poses=[pose(d,''),pose(d,'patient_')],cube=[*block.xpos,*block.xquat],contact=rm,pm=pm,pc=pc,rc=rc,dc=dc,dist=dist,tilt=tilt))
 result=dict(final=round(math.degrees(math.acos(np.clip(last_up,-1,1))),2),best=round(best,2),held=held,dual=dual,direct=direct,hit=hit,slip=slip,clear=bool(endclear))
 if save:
  (base/('right.json' if side==1 else 'left.json')).write_text(json.dumps(frames))
  np.savetxt(base/f'contacts{side}.csv',logs,header='seconds,patient_fork_cube,rescuer_fork_cube,direct_robot_contact,patient_up',delimiter=',',comments='')
 return result
def task(p):return p,trial(p,1)
if __name__=='__main__':
 rng=np.random.default_rng(84)
 ps=[[216.7,-14.8,.31,.84,.04,.50]]+[[round(rng.uniform(125,266),1),round(rng.uniform(-24,20),1),round(rng.uniform(0,.58),2),round(rng.uniform(.42,.98),2),round(rng.uniform(.015,.21),2),round(rng.uniform(.17,.73),2)] for _ in range(560)]
 with ProcessPoolExecutor(6) as pool:
  for p,r in pool.map(task,ps,chunksize=2): print(json.dumps([p,r]),flush=True)
